public class Percolation {

        private static final int[][] DIRECT = { { 1, 0 }, { -1, 0 }, { 0, 1 },
                        { 0, -1 } };
        private static final int DIRECT_X = 0;
        private static final int DIRECT_Y = 1;
        private WeightedQuickUnionUF weightedUFBackwash = null;
        private int squareN = 0;
        private boolean[][] openedSquare;
        private boolean isPercolation = false;

        public Percolation(int N) {
                weightedUFBackwash = new WeightedQuickUnionUF(N * N + 1);
                squareN = N;
                isPercolation = false;
                openedSquare = new boolean[N + 1][N + 1];
                for (int i = 0; i <= N; i++) {
                        for (int j = 0; j <= N; j++) {
                                openedSquare[i][j] = false;
                        }
                }
        }

        public void open(int i, int j) {
                if ((i <= 0) || (i > squareN))
                        throw new java.lang.IndexOutOfBoundsException();
                if ((j <= 0) || (j > squareN))
                        throw new java.lang.IndexOutOfBoundsException();
                openedSquare[i][j] = true;
                int openNum = convertCoordinate(i, j);
                if (i == 1) {
                        weightedUFBackwash.union(0, openNum);
                }
                for (int k = 0; k < 4; k++) {
                        int newX = i + DIRECT[k][DIRECT_X];
                        int newY = j + DIRECT[k][DIRECT_Y];
                        if ((newX > 0) && (newX <= squareN) && (newY > 0)
                                        && (newY <= squareN)) {
                                if (openedSquare[newX][newY]) {
                                        int newNum = convertCoordinate(newX,
                                                        newY);
                                        weightedUFBackwash.union(openNum,
                                                        newNum);
                                }
                        }
                }

                if (!isPercolation) {
                        for (int k = 1; k <= squareN; k++) {
                                int nowNum = convertCoordinate(squareN, k);
                                if (weightedUFBackwash.connected(0, nowNum)) {
                                        isPercolation = true;
                                }
                        }

                }

        }

        public boolean isOpen(int i, int j) {
                if ((i <= 0) || (i > squareN))
                        throw new java.lang.IndexOutOfBoundsException();
                if ((j <= 0) || (j > squareN))
                        throw new java.lang.IndexOutOfBoundsException();
                return openedSquare[i][j];
        }

        public boolean isFull(int i, int j) {
                if ((i <= 0) || (i > squareN))
                        throw new java.lang.IndexOutOfBoundsException();
                if ((j <= 0) || (j > squareN))
                        throw new java.lang.IndexOutOfBoundsException();
                return weightedUFBackwash.connected(0, convertCoordinate(i, j));
        }

        public boolean percolates() {
                return isPercolation;
        }

        private int convertCoordinate(int i, int j) {
                return (i - 1) * squareN + j;
        }

}
